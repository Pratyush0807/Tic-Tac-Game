const gameBoard = document.querySelector('.game-board');
const cells = document.querySelectorAll('[data-cell]');
const statusDisplay = document.getElementById('status');
const restartButton = document.getElementById('restartButton');
let currentPlayer = 'X';
let gameActive = true;
let gameState = ['', '', '', '', '', '', '', '', ''];

const winningCombinations = [
    [0, 1, 2], [3, 4, 5], [6, 7, 8], // Rows
    [0, 3, 6], [1, 4, 7], [2, 5, 8], // Columns
    [0, 4, 8], [2, 4, 6] // Diagonals
];

function handleCellClick(e) {
    const cell = e.target;
    const cellIndex = Array.from(cells).indexOf(cell);

    if (gameState[cellIndex] !== '' || !gameActive) return;

    gameState[cellIndex] = currentPlayer;
    cell.textContent = currentPlayer;
    cell.setAttribute('data-player', currentPlayer);
    
    const winningResult = checkWin();
    if (winningResult.won) {
        gameActive = false;
        statusDisplay.textContent = `Player ${currentPlayer === 'X' ? '1' : '2'} Wins!`;
        drawWinningLine(winningResult.combination, winningResult.type);
        return;
    }

    if (checkDraw()) {
        gameActive = false;
        statusDisplay.textContent = "Game Draw!";
        return;
    }

    currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
    statusDisplay.textContent = `Player ${currentPlayer === 'X' ? '1' : '2'}'s Turn (${currentPlayer})`;
}

function checkWin() {
    for (let i = 0; i < winningCombinations.length; i++) {
        const [a, b, c] = winningCombinations[i];
        if (gameState[a] && gameState[a] === gameState[b] && gameState[a] === gameState[c]) {
            let type;
            // Determine line type
            if (i < 3) type = `horizontal row-${i + 1}`; // Rows
            else if (i < 6) type = `vertical col-${(i - 2)}`; // Columns
            else type = `diagonal ${i === 6 ? 'left' : 'right'}`; // Diagonals
            
            return {
                won: true,
                combination: winningCombinations[i],
                type: type
            };
        }
    }
    return { won: false };
}

function drawWinningLine(combination, type) {
    const line = document.createElement('div');
    line.className = `winning-line ${type}`;
    gameBoard.appendChild(line);
}

function checkDraw() {
    return gameState.every(cell => cell !== '');
}

function restartGame() {
    currentPlayer = 'X';
    gameActive = true;
    gameState = ['', '', '', '', '', '', '', '', ''];
    statusDisplay.textContent = "Player 1's Turn (X)";
    cells.forEach(cell => {
        cell.textContent = '';
        cell.removeAttribute('data-player');
    });
    // Remove winning line if it exists
    const winningLine = document.querySelector('.winning-line');
    if (winningLine) {
        winningLine.remove();
    }
}

cells.forEach(cell => {
    cell.addEventListener('click', handleCellClick);
});

restartButton.addEventListener('click', restartGame); 